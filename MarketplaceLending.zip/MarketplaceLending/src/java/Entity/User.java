/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.ArrayList;

/**
 *
 * @author adityas.2014
 */
public class User {
    private String uid;
    private String type;
    private String username;
    private String password;
    private Account account; 
    private ArrayList<CommLog> messages;
    private ArrayList<Ledger> transactions;

    public User(String uid, String type, String username, String password) {
        uid=this.uid;
        type=this.type;
        username=this.username;
        password=this.password;
    }
}
