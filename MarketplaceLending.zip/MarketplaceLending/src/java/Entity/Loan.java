/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.ArrayList;

/**
 *
 * @author adityas.2014
 */
public class Loan {
    private ArrayList<Portfolio> portfolio;
    private ArrayList<Journal> journal;
    private Investor investor;
    private Borrower borrower;
    private Schedule schedule;
    private RiskGrade riskGrade;
    
    private double amount;
    private double interestRate;
    private double duration;
    private String status;
    private String timestamp; //loan origin time
    private double levelOfFunding;
    private double balance;
    private int countOfInvestors;
    private String dod;
    private String day;
     
    
}
