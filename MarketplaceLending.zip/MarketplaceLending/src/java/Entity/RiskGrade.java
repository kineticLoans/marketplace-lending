/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.ArrayList;

/**
 *
 * @author adityas.2014
 */
public class RiskGrade {
    private ArrayList<Loan> loans;
    private String rgid;
    private String version;
    private String LetterGrade;
    private String bir;//borrower interest rate
    private String iir; //investor interest rate
}
