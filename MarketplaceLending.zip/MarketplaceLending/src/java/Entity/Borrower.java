/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.util.ArrayList;

/**
 *
 * @author adityas.2014
 */
public class Borrower {
    private String bid;
    private String name;
    private String email;
    private User user;
    private String contact;
    private CreditScore creditScore;
    private String dob;
    private String gender;
    private String income;
    private String employment;
    private ArrayList<Portfolio> portfolio;
    private ArrayList<Loan> loans;
    private ArrayList<Journal> journal;
}
