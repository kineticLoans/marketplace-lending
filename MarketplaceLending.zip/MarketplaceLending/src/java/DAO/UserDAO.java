/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ConnectionDB.ConnectionManager;
import Entity.User;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author adityas.2014
 */
public class UserDAO {
    Connection conn;
    PreparedStatement stmt;
    ResultSet result;
    ArrayList<User> users;
    
    public void create(String uid, String type, String username, String password) throws SQLException{
        conn = ConnectionManager.getConnection();
        stmt = conn.prepareStatement("INSERT INTO User " +
                   "VALUES ("+uid+","+type+","+username+","+password+");");
        stmt.executeUpdate();
        
    }
    
    public ArrayList<User> retrieveAll() throws SQLException{
        users = new ArrayList<User>();
        conn = ConnectionManager.getConnection();
        stmt = conn.prepareStatement("select * from users");
        result = stmt.executeQuery();
        
        while(result.next()){
            String uid=result.getString("uid");
            String type=result.getString("type");
            String username=result.getString("username");
            String password=result.getString("password");
            users.add(new User(uid,type,username,password));
        }
        
        if (conn != null) {
            ConnectionManager.close(conn, stmt, result);
        }
        return users;
    }
    
    public User retrieve(String username) throws SQLException, IOException {
        User user = null;
        conn = ConnectionManager.getConnection();
        stmt = conn.prepareStatement("Select * from users where username = '" + username + "'");
        result = stmt.executeQuery();
        while (result.next()) {
            String uid=result.getString("uid");
            String type=result.getString("type");
            String password=result.getString("password");
            user = new User(uid,type,username,password);
        }
        if (conn != null) {
            ConnectionManager.close(conn, stmt, result);
        }
        return user;
    }
    
    public void update(String username, String password) throws SQLException {

        conn = ConnectionManager.getConnection();
        PreparedStatement ps = conn.prepareStatement("UPDATE users SET password =? WHERE username =?");

        // set pstmt parameters
        ps.setString(1, password);
        ps.setString(2, username);
        // call executeUpdate 
        ps.executeUpdate();
        ps.close();
        if (conn != null) {
            ConnectionManager.close(conn, ps, result);
        }
    }
    
    public void deleteAll() throws SQLException {
        conn = ConnectionManager.getConnection();
        stmt = conn.prepareStatement("TRUNCATE TABLE users");
        stmt.executeUpdate();
        if (conn != null) {
            ConnectionManager.close(conn, stmt, result);
        }
    }

}
